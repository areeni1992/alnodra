<div class="mobile-menu">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="social text-center my-3">
                    <a href="" class="facebook">
                        <i class="fab fa-facebook-f mr-4"></i>
                    </a>
                    <a href="" class="twitter">
                        <i class="fab fa-twitter    mr-4"></i>
                    </a>
                    <a href="" class="youtube">
                        <i class="fab fa-youtube    mr-4"></i>
                    </a>
                    <a href="" class="instagram">
                        <i class="fab fa-instagram  mr-4"></i>
                    </a>
                    <a href="" class="search">
                        <i class="fas fa-search     mr-4"></i>
                    </a>
                </div>
            </div>
            <div class="col-12">
                <ul class="list list-unstyled p-0 m-0 text-right">
                    <li><a href="#">الرئيسية</a></li>
                    <li><a href="#">خدمات</a></li>
                    <li><a href="#">اعمالنا</a></li>
                    <li><a href="#">من نحن </a></li>
                    <li><a href="#">اتصل بنا</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

