<div class="footer" style="background-image: url("assets/images/footerbackground.jpg")">
    <div class="container">
        <div class="row no-gutters">
            <div class="copyright d-none d-md-block  col-md-4 text-right pr-0 font-weight-bold">
                الندرة للتجارة والديكور @2019
            </div>
            <div class="col-6 col-md-4 text-center">
                <div class="social">
                    <a href="#" class="facebook">
                        <i class="fab fa-facebook-f "></i>
                    </a>
                    <a href="#" class="twitter">
                        <i class="fab fa-twitter    mr-4"></i>
                    </a>
                    <a href="#" class="youtube">
                        <i class="fab fa-youtube    mr-4"></i>
                    </a>
                    <a href="#" class="instagram">
                        <i class="fab fa-instagram  mr-4"></i>
                    </a>
                </div>
            </div>
            <div class="col-6 col-md-4 pl-0">
                <div class="logo text-left">
                    <a href="#">
                        <img src="assets/images/footlogo.png" alt="" class="img-fluid">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
