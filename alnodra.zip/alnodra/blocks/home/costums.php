<section class="costums py-5">
    <div class="container">
        <h3 class="marke text-right">عملائنا<span></span></h3>
        <div class="row text-center no-gutters">
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <a href="#" class="swiper-slide mx-2">
                        <div class="border shadow-sm">
                            <img src="uploads/costum1.png" alt="" class="img-fluid">
                        </div>
                    </a>
                    <a href="#" class="swiper-slide mx-2">
                        <div class="border shadow-sm">
                            <img src="uploads/costum2.png" alt="" class="img-fluid">
                        </div>
                    </a>
                    <a href="#" class="swiper-slide mx-2">
                        <div class="border shadow-sm">
                            <img src="uploads/costum3.png" alt="" class="img-fluid">
                        </div>
                    </a>
                    <a href="#" class="swiper-slide mx-2">
                        <div class="border shadow-sm">
                            <img src="uploads/costum4.png" alt="" class="img-fluid">
                        </div>
                    </a>
                    <a href="#" class="swiper-slide mx-2">
                        <div class="border shadow-sm">
                            <img src="uploads/costum5.png" alt="" class="img-fluid">
                        </div>
                    </a>
                    <a href="#" class="swiper-slide mx-2">
                        <div class="border shadow-sm">
                            <img src="uploads/costum1.png" alt="" class="img-fluid">
                        </div>
                    </a>
                    <a href="#" class="swiper-slide mx-2">
                        <div class="border shadow-sm">
                            <img src="uploads/costum2.png" alt="" class="img-fluid">
                        </div>
                    </a>
                    <a href="#" class="swiper-slide mx-2">
                        <div class="border shadow-sm">
                            <img src="uploads/costum3.png" alt="" class="img-fluid">
                        </div>
                    </a>
                    <a href="#" class="swiper-slide mx-2">
                        <div class="border shadow-sm">
                            <img src="uploads/costum4.png" alt="" class="img-fluid">
                        </div>
                    </a>
                    <a href="#" class="swiper-slide mx-2">
                        <div class="border shadow-sm">
                            <img src="uploads/costum5.png" alt="" class="img-fluid">
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>