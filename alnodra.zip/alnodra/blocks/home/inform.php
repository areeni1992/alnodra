<section class="inform py-5" id="inform">
    <div class="container">
        <h3 class="marke text-right">مركز المعرفة <span></span></h3>
        <div class="row align-items-center text-right">
                <div class="col-sm-12 col-md-6 col-lg-3 mb-sm-2">
                    <div class="item border shadow">
                        <a href="#">
                            <div class="img">
                                <img src="uploads/inform1.jpg" alt="" class="img-fluid">
                            </div>
                            <p class="m-0 p-3">                                هذا النص مثال لنص يمكن أن يستبدل في نفس المساحة
                            </p>
                        </a>

                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-3 mb-sm-2">
                    <div class="item border shadow">
                        <a href="#">
                            <div class="img">
                                <img src="uploads/inform2.jpg" alt="" class="img-fluid">
                            </div>
                            <p class="m-0 p-3">                                هذا النص مثال لنص يمكن أن يستبدل في نفس المساحة
                            </p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-3">
                    <div class="item border shadow">
                        <a href="#">
                            <div class="img">
                                <img src="uploads/inform3.jpg" alt="" class="img-fluid">
                            </div>
                            <p class="m-0 p-3">                                هذا النص مثال لنص يمكن أن يستبدل في نفس المساحة
                            </p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-3">
                    <div class="item border shadow">
                        <a href="#">
                            <div class="img">
                                <img src="uploads/inform4.jpg" alt="" class="img-fluid">
                            </div>
                            <p class="m-0 p-3">                                هذا النص مثال لنص يمكن أن يستبدل في نفس المساحة
                            </p>
                        </a>
                    </div>
                </div>
        </div>
    </div>
</section>