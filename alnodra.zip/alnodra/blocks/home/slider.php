<div class="the-slider">
    <!-- Swiper -->
    <div class="swiper-container">

        <div class="swiper-wrapper">
            <div class="swiper-slide">
                <div class="item" style="background-image: url('uploads/slide1.jpg')">
                    <a href="#">
                        <div class="overlay">
                            <div class="container">
                                <p class="text-right">
                                    <span></span>
                                    هذا النص مثال لنص يمكن أن يستبدل في نفس المساحة
                                </p>
                            </div>
                        </div>

                    </a>

                </div>
            </div>
            <div class="swiper-slide">
                <div class="item" style="background-image: url('uploads/slide2.jpg')">
                    <a href="#">
                        <div class="overlay">
                            <div class="container">
                                <p class="text-right">
                                    <span></span>
                                    هذا النص مثال لنص يمكن أن يستبدل في نفس المساحة
                                </p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <!-- Add Arrows -->
        <div class="swiper-button-next">
            <i class="fas fa-chevron-left"></i>
        </div>
        <div class="swiper-button-prev">
            <i class="fas fa-chevron-right"></i>
        </div>
    </div>
</div>