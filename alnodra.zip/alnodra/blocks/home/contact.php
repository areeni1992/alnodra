<div class="contact py-5" id="contact">
    <div class="container">
        <h3 class="marke text-right">تواصل معنا<span></span></h3>
        <div class="row text-center border shadow pt-5 no-gutters">
                <div class="box1 col-4 mb-3 col-lg-4">
                    <i class="fas fa-map-marker-alt fa-2x"></i>
                    <span class="d-block mt-2">قطر- الوكرة- شارع الوكرة العام</span>
                </div>
                <div class="box2 col-4 mb-3 col-lg-4 border-right border-left">
                    <a href="telto:0598263821">
                        <i class="fas fa-phone-volume fa-2x"></i>
                        <span class="d-block mt-2">0598263821</span>
                    </a>
                </div>
                <div class="box3 col-4 mb-3 col-lg-4">
                    <a href="mail:areeni1992@hotmail.com">
                        <i class="fas fa-envelope fa-2x"></i>
                        <span class="d-block mt-2">areeni1992@ hotmail.com</span>
                    </a>
                </div>
            <div class="map col-lg-12 p-0 mt-4">
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d7215.878324016032!2d51.51424842842007!3d25.272631923883658!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sar!2s!4v1574928431449!5m2!1sar!2s" width="100%" height="400px" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            </div>
        </div>
    </div>
</div>