<section class="our-works py-5" style="background-image: url('assets/images/background.jpg')" id="work">
    <div class="container text-right">
        <h3 class="marke">أخر أعمالنا<span></span></h3>
        <div class="row">
            <div class="col-sm-12 col-md-4 col-lg-6 p-2">
                <div class="img mh-100">
                    <a href="#">
                        <div class="over">
                            <img src="uploads/ourwork1.jpg" alt="" class="img-fluid h-100">
                            <span>text</span>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-sm-12 col-md-4 col-lg-3 p-2">
                <div class="img mh-100">
                    <a href="#">
                        <div class="over">
                            <img src="uploads/ourwork2.jpg" alt="" class="img-fluid h-100">
                            <span>text</span>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-sm-12 col-md-4 col-lg-3 p-2">
                <div class="img mh-100">
                    <a href="#">
                        <div class="over">
                            <img src="uploads/ourwork3.jpg" alt="" class="img-fluid h-100">
                            <span>text</span>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-sm-12 col-md-4 col-lg-3 p-2">
                <div class="img mh-100">
                    <a href="#">
                        <div class="over">
                            <img src="uploads/ourwork3.jpg" alt="" class="img-fluid h-100">
                            <span>برجولات</span>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-sm-12 col-md-4 col-lg-3 p-2">
                <div class="img mh-100">
                    <a href="#">
                        <div class="over">
                            <img src="uploads/ourwork4.jpg" alt="" class="img-fluid h-100">
                            <span>text</span>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-sm-12 col-md-4 col-lg-6 p-2">
                <div class="img mh-100">
                    <a href="#">
                        <div class="over">
                            <img src="uploads/ourwork5.jpg" alt="" class="img-fluid h-100">
                            <span>text</span>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

</section>